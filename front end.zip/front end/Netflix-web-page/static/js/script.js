// Frequently asked Question style in JS

function FrequentQues(answerId, iconId) {
    const answer = document.getElementById(answerId);
    const icon = document.getElementById(iconId);

    if (answer.style.display === "none" || !answer.style.display) {
        answer.style.display = "block"; 
        icon.textContent = "×";
    } else {
        answer.style.display = "none";
        icon.textContent = "+";
    }
}

//  Pop Window JS Function

document.querySelectorAll(".movie-image").forEach((image) => {
    image.addEventListener("click", () => {
      document.getElementById("carouselModalTitle").innerText = image.dataset.title;
      document.getElementById("carouselModalImage").src = image.src;
      document.getElementById("carouselModalHeading").innerText = image.dataset.heading;
      document.getElementById("carouselModalParagraph").innerText = image.dataset.paragraph;
    });
  });

  
  